package com.teoria;

import java.io.File;
import java.io.FileWriter;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

public class Cliente {
		
	//getter y setter}
		private String nombre;
		private  String ciudad;
		private float facturacion;
		
		public String getNombre() {
			return nombre;
		}
		public void setNombre(String nombre) {
			this.nombre = nombre;
		}
		public String getCiudad() {
			return ciudad;
		}
		public void setCiudad(String ciudad) {
			this.ciudad = ciudad;
		}
		public float getFacturacion() {
			return facturacion;
		}
		public void setFacturacion(float facturacion) {
			this.facturacion = facturacion;
		}
		
		
		

}
