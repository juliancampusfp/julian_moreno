package com.teoria;

public class Producto {

	private String nombre;
	private  int Unidades;
	private float precio;
	
	//getter y setter
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getUnidades() {
		return Unidades;
	}
	public void setUnidades(int unidades) {
		Unidades = unidades;
	}
	public float getPrecio() {
		return precio;
	}
	public void setPrecio(float precio) {
		this.precio = precio;
	}
	
	
	
}
